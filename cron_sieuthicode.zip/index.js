//sieuthicode.net - NGUYỄN NHẬT LỘC
//chạy đa luồng
const async = require('async');
const cron = require('node-cron');
const request = require('request');

const urls = [
    'https://shopclone6.cmsnt.site/cron/momo.php',
    'https://shopclone6.cmsnt.site/cron/bank.php',
    'https://shopclone6.cmsnt.site/cron/thesieure.php',
    'https://shopclone6.cmsnt.site/cron/zalopay.php',
    'https://shopclone6.cmsnt.site/cron/cron.php',
    'https://shopclone6.cmsnt.site/cron/checklivefb.php',
    'https://shopclone6.cmsnt.site/cron/cron1.php',
    'https://shopclone6.cmsnt.site/cron/cron2.php',
    'https://shopclone6.cmsnt.site/cron/cron3.php',
    'https://shopclone6.cmsnt.site/cron/cron4.php',
    'https://shopclone6.cmsnt.site/cron/cron5.php',
    'https://shopclone6.cmsnt.site/cron/cron6.php',
    'https://shopclone6.cmsnt.site/cron/cron7.php',
    'https://shopclone6.cmsnt.site/cron/cron8.php',
    'https://shopclone6.cmsnt.site/cron/cron9.php',
    'https://shopclone6.cmsnt.site/cron/UpdateRateService.php',
    'https://shopclone6.cmsnt.site/cron/UpdateHistoryService.php',
    'https://shopclone6.cmsnt.site/cron/sending_email.php',
    'https://shopclone6.cmsnt.site/cron/cron_dongvanfb.php',
    'https://shopclone6.cmsnt.site/cron/nowpayments.php'
];


cron.schedule('*/1 * * * * *', () => {
  console.log('Starting requests at', new Date());

  async.mapLimit(urls, 20, (url, callback) => {
    request(url, (error, response, body) => {
      if (error) {
        return callback(error);
      }

      callback(null, body);
    });
  }, (error, results) => {
    if (error) {
      console.error(error);
    }

    console.log(results);
  });
});
